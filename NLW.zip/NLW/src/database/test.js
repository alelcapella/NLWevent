const Database = require('./db');

Database.then(function(db){
    
}) 