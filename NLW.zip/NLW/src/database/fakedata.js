module.exports = [
    {
        id: 1,
        lat: "-22.278682",
        lng: "-48.5487495",
        name:"Associação Lar",
        description: "A Associação Lar acolhe crianças e adolescentes, cujos direitos tenham sidos ameaçados.",
        images: [ "https://images.unsplash.com/photo-1597553954309-30454e8502f9?ixlib=rb-1.2.1&q=80&fm=jpg&crop=entropy&cs=tinysrgb&w=1080&fit=max&ixid=eyJhcHBfaWQiOjF9",

        "https://images.unsplash.com/photo-1583526362016-c3137c71cc3a?ixlib=rb-1.2.1&q=80&fm=jpg&crop=entropy&cs=tinysrgb&w=1080&fit=max&ixid=eyJhcHBfaWQiOjF9",

        ],

        instructions: "Venha como se sentir a vontade e traga muito amor e paciência para dar.",

        opening_hours: "Horário de Visitas - 08h até 18h",

        open_on_weekends: "1",
    },

        {
            id: 2,
            lat: "-22.272209",
            lng: "-48.5577353",
            name:"Nosso Lar",
            description: "Acolher crianças e adolescentes.",
            images: [ "https://images.unsplash.com/photo-1597553954309-30454e8502f9?ixlib=rb-1.2.1&q=80&fm=jpg&crop=entropy&cs=tinysrgb&w=1080&fit=max&ixid=eyJhcHBfaWQiOjF9",
    
            "https://images.unsplash.com/photo-1583526362016-c3137c71cc3a?ixlib=rb-1.2.1&q=80&fm=jpg&crop=entropy&cs=tinysrgb&w=1080&fit=max&ixid=eyJhcHBfaWQiOjF9",
    
            ],
    
            instructions: "Venha como se sentir a vontade e traga muito amor e paciência para dar.",
    
            opening_hours: "Horário de Visitas - 08h até 18h",
    
            open_on_weekends: "0",
        },
]